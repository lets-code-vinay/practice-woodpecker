module.exports = {
  privateKey: "Atanu"
};
