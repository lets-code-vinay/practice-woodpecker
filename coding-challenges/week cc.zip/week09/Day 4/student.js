var data =[
    {
    name:'RAKESH REDDY',
    age:23,
    address:'HYDERABAD'
},

{
    name:'RAKESH REDDY',
    age:23,
    address:'HYDERABAD'
},

{
    name:'RAKESH REDDY',
    age:23,
    address:'HYDERABAD'
},

{
    name:'RAKESH REDDY',
    age:23,
    address:'HYDERABAD'
},

{
    name:'RAKESH REDDY',
    age:23,
    address:'HYDERABAD'
},

{
    name:'RAKESH REDDY',
    age:23,
    address:'HYDERABAD'
}
]
module.exports = {
    data:data }