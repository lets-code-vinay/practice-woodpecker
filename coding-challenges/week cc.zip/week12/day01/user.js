module.exports = [
  { name: "Vinay", email: "Vinay.Kumar.215@gmail.com", password: "12345" },
  { name: "Arjun", email: "arjunsam@gmail.com", password: "12345" }
];
